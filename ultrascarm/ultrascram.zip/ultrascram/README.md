# UltraScram

**UltraScram** is a double web proxy that combines [Ultraviolet](https://github.com/titaniumnetwork-dev/Ultraviolet) and [Scramjet](https://github.com/MercuryWorkshop/scramjet) into a single, self-hosted application. Users can switch between the two proxy engines on the fly using the toggle on the homepage — no reload required.

---

## How It Works

UltraScram runs a single Express HTTP server that:

- Serves the unified frontend from `public/`
- Hosts Ultraviolet's static assets at `/uv/`
- Hosts Scramjet's static assets at `/scram/`
- Hosts Epoxy (UV's transport) at `/epoxy/`
- Hosts libcurl (SJ's transport) at `/libcurl/`
- Hosts bare-mux (shared transport negotiation layer) at `/baremux/`
- Handles WebSocket upgrades via a single `/wisp/` Wisp endpoint

Both proxy engines share the same Wisp server. `bare-mux` handles negotiating which transport is active on the client side — Epoxy for Ultraviolet, libcurl for Scramjet — so there's no conflict.

### Service Workers

Two service workers run side by side:

| SW file | Scope | Purpose |
|---|---|---|
| `/uv/sw.js` | `/uv/service/` | Intercepts and proxies requests through Ultraviolet |
| `/sw.js` | `/` | Intercepts Scramjet-routed requests via `scramjet.route()` |

Because UV's SW is scoped strictly to `/uv/service/*` and Scramjet's SW uses its own internal routing check (`scramjet.route(event)`), they do not interfere with each other.

---

## Architecture Diagram

```
Browser
  │
  ├─ GET /         → public/index.html  (UltraScram UI)
  ├─ GET /uv/*     → Ultraviolet package dist files
  ├─ GET /scram/*  → Scramjet package dist files
  ├─ GET /epoxy/*  → Epoxy transport (used by UV)
  ├─ GET /libcurl/*→ libcurl transport (used by SJ)
  ├─ GET /baremux/*→ bare-mux shared negotiation layer
  │
  ├─ WS  /wisp/   → wisp-server-node  (single shared Wisp endpoint)
  │
  ├─ SW  /uv/sw.js          scope: /uv/service/
  └─ SW  /sw.js             scope: /  (Scramjet routing check inside)
```

---

## Proxy Toggle

The homepage shows a **Ultraviolet / Scramjet** pill toggle above the search bar. The user's last-used choice is stored in `localStorage` under the key `us-proxy` so it persists across page loads.

When the user submits a URL or search query:

- **Ultraviolet selected** → bare-mux sets the Epoxy transport → URL is encoded with UV's XOR codec → loaded into a static `<iframe id="uv-frame">`
- **Scramjet selected** → bare-mux sets the libcurl transport → `ScramjetController.createFrame()` creates a fresh frame → `frame.go(url)` navigates it

Switching proxy mid-session resets the frame cleanly (old frames are removed from the DOM before the new one is created).

---

## Requirements

- **Node.js** >= 24.0.0
- **pnpm** >= 10.x  (managed via `corepack`)

---

## Installation

```bash
# Clone the repo
git clone https://github.com/your-username/ultrascram.git
cd ultrascram

# Enable corepack so pnpm is available
corepack enable

# Install dependencies
pnpm install
```

---

## Running

```bash
# Start on the default port (8080)
pnpm start

# Or on a custom port
PORT=3000 pnpm start
```

Then open [http://localhost:8080](http://localhost:8080) in your browser.

> **Note:** Service workers require either `https://` or `localhost` / `127.0.0.1`. Running on a raw IP over HTTP will cause SW registration to fail.

---

## Deployment

### Docker

```bash
# Build and run
docker build -t ultrascram .
docker run -p 8080:8080 ultrascram
```

### Docker Compose

```bash
docker compose up -d
```

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8080` | Port the HTTP server listens on |

---

## File Structure

```
ultrascram/
├── src/
│   └── index.js              # Express server — all routes + Wisp handler
├── public/
│   ├── index.html            # UltraScram homepage with proxy toggle
│   ├── index.js              # Frontend JS: UV + SJ dispatch logic
│   ├── index.css             # Styles (merged UV + SJ, plus toggle UI)
│   ├── search.js             # URL/search query parser (shared)
│   ├── register-sw.js        # Registers both UV and SJ service workers
│   ├── sw.js                 # Scramjet service worker (served at /)
│   ├── error.js              # Error page SW re-registration helper
│   ├── 404.html              # 404 page
│   ├── credits.html          # Combined license attributions
│   ├── favicon.ico           # Favicon
│   └── uv/
│       └── uv.config.js      # Ultraviolet proxy config (prefix, codec, etc.)
├── package.json
├── Dockerfile
├── docker-compose.yml
└── README.md
```

---

## Dependencies

### Runtime

| Package | Purpose |
|---|---|
| `@titaniumnetwork-dev/ultraviolet` | Ultraviolet proxy engine and service worker |
| `@mercuryworkshop/scramjet` | Scramjet proxy engine and service worker |
| `@mercuryworkshop/bare-mux` | Transport negotiation layer (shared) |
| `@mercuryworkshop/epoxy-transport` | WebSocket transport used by Ultraviolet |
| `@mercuryworkshop/libcurl-transport` | WebSocket transport used by Scramjet |
| `express` | HTTP server framework |
| `wisp-server-node` | Server-side Wisp WebSocket handler |
| `ws` | WebSocket support for Node.js |

### Dev

| Package | Purpose |
|---|---|
| `eslint` | JS linting |
| `prettier` | Code formatting |

---

## Credits

- **Ultraviolet** and **Ultraviolet-App** — [TitaniumNetwork](https://github.com/titaniumnetwork-dev)
- **Scramjet** and **Scramjet-Demo** — [Mercury Workshop](https://github.com/MercuryWorkshop)
- **bare-mux**, **epoxy-transport**, **libcurl-transport** — [Mercury Workshop](https://github.com/MercuryWorkshop)

All upstream projects are licensed under the GNU Affero General Public License v3. See [credits.html](public/credits.html) for full license texts.

---

## License

AGPL-3.0-or-later
