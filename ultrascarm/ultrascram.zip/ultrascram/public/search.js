"use strict";

/**
 * Converts a user's raw input (URL or search query) into a fully qualified URL.
 *
 * @param {string} input
 * @param {string} template  Template for a search query, e.g. "https://google.com/search?q=%s"
 * @returns {string} Fully qualified URL
 */
function search(input, template) {
	try {
		// input is already a valid absolute URL
		return new URL(input).toString();
	} catch (err) {
		// not a valid URL
	}

	try {
		// input looks like a bare hostname, e.g. "example.com"
		const url = new URL(`http://${input}`);
		if (url.hostname.includes(".")) return url.toString();
	} catch (err) {
		// still not a valid URL
	}

	// Fall back: treat input as a search query
	return template.replace("%s", encodeURIComponent(input));
}
