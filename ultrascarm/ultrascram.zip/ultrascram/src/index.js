import { join } from "node:path";
import { hostname } from "node:os";
import { createServer } from "node:http";
import express from "express";
import wisp from "wisp-server-node";

import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { scramjetPath } from "@mercuryworkshop/scramjet/path";
import { libcurlPath } from "@mercuryworkshop/libcurl-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

const app = express();

// Load our public files first — they take priority over any vendor files.
app.use(express.static("./public"));

// Ultraviolet vendor files
app.use("/uv/", express.static(uvPath));

// Scramjet vendor files
app.use("/scram/", express.static(scramjetPath));

// Transport layers
// Epoxy is used by Ultraviolet; libcurl is used by Scramjet.
app.use("/epoxy/", express.static(epoxyPath));
app.use("/libcurl/", express.static(libcurlPath));

// bare-mux is shared — both proxies use it for transport negotiation.
app.use("/baremux/", express.static(baremuxPath));

// 404 fallback
app.use((req, res) => {
	res.status(404);
	res.sendFile("./public/404.html", { root: "." });
});

const server = createServer();

server.on("request", (req, res) => {
	// Required for SharedArrayBuffer support (used by Scramjet's WASM module)
	res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
	res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
	app(req, res);
});

server.on("upgrade", (req, socket, head) => {
	// Single wisp endpoint serves both proxies — bare-mux handles transport
	// selection on the client side (epoxy for UV, libcurl for SJ).
	if (req.url.endsWith("/wisp/")) {
		wisp.routeRequest(req, socket, head);
		return;
	}
	socket.end();
});

let port = parseInt(process.env.PORT || "");

if (isNaN(port)) port = 8080;

server.on("listening", () => {
	const address = server.address();

	console.log("UltraScram listening on:");
	console.log(`\thttp://localhost:${address.port}`);
	console.log(`\thttp://${hostname()}:${address.port}`);
	console.log(
		`\thttp://${
			address.family === "IPv6" ? `[${address.address}]` : address.address
		}:${address.port}`
	);
});

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

function shutdown() {
	console.log("SIGTERM signal received: closing HTTP server");
	server.close();
	process.exit(0);
}

server.listen({
	port,
});
